"""Challenge novelty filter + binder scoring for designed CDRH3 loops.

Rules (12-her2.md):
  1. CDRH3 must differ at >=2 of its 10 positions from EVERY sequence in the provided
     data (FACS 524,346 + SPR designs) -> Hamming distance >= 2 to all known loops.
  2. At most 70% identical to trastuzumab's WGGDGFYAMD -> >= 3 of 10 positions changed.
Also reports P(high HER2 binder) from the FACS-trained model.
"""
import numpy as np, pandas as pd, pickle, sys, json

AA = "ACDEFGHIKLMNPQRSTVWY"
TZ = "WGGDGFYAMD"
DD = "/home/hackathon/guled/denovo/data/"

def load_known():
    facs = pd.read_csv(DD + "tz_her2_facs_3classes_524346.csv", usecols=["cdrh3","binding_class"])
    spr  = pd.read_csv(DD + "trastuzumab_her2_spr_all_768.csv", usecols=["cdrh3"])
    known = set(facs.cdrh3.str.strip()) | set(spr.cdrh3.str.strip())
    cls = dict(zip(facs.cdrh3.str.strip(), facs.binding_class))
    return known, cls

def hamming(a, b):
    return sum(x != y for x, y in zip(a, b))

def novel(seq, known):
    """True if Hamming >= 2 from every known loop. Checks the design and all 190 of
    its 1-mutant neighbours against the known set -- a hit means distance 0 or 1."""
    if seq in known: return False
    for p in range(len(seq)):
        for a in AA:
            if a == seq[p]: continue
            if seq[:p] + a + seq[p+1:] in known: return False
    return True

def onehot(seqs):
    idx = {a: i for i, a in enumerate(AA)}
    X = np.zeros((len(seqs), 200), dtype=np.float32)
    for n, s in enumerate(seqs):
        for p, c in enumerate(s[:10]):
            if c in idx: X[n, p*20 + idx[c]] = 1
    return X

def evaluate(seqs, model_path="/home/hackathon/guled/denovo/results/binder_lgbm.pkl"):
    known, cls = load_known()
    rows = []
    for s in seqs:
        s = s.strip().upper()
        d_tz = hamming(s, TZ) if len(s) == len(TZ) else None
        canonical = all(c in AA for c in s)
        rows.append(dict(cdrh3=s, length=len(s), canonical=canonical,
                         edit_from_tz=d_tz,
                         in_screen=s in known,
                         screen_class=cls.get(s, ""),
                         novel_vs_data=novel(s, known) if len(s) == 10 else None,
                         tz_identity_ok=(d_tz is not None and d_tz >= 3)))
    df = pd.DataFrame(rows)
    # a loop with a non-canonical residue (e.g. X) cannot be synthesised -- reject it
    df["passes_challenge_filter"] = (df.novel_vs_data.fillna(False)
                                     & df.tz_identity_ok.fillna(False)
                                     & df.canonical)
    try:
        m = pickle.load(open(model_path, "rb"))
        ten = df.length == 10
        df.loc[ten, "p_high_binder"] = m.predict_proba(onehot(df.loc[ten, "cdrh3"]))[:, 1]
    except FileNotFoundError:
        print("note: binder model not trained yet", file=sys.stderr)
    return df

if __name__ == "__main__":
    seqs = [l.strip() for l in (open(sys.argv[1]) if len(sys.argv) > 1 else sys.stdin) if l.strip()]
    df = evaluate(seqs)
    pd.set_option("display.width", 200)
    print(df.to_string(index=False))
