"""Which folding model's ipTM separates real ab-ag pairs from shuffled ones?
Data: Smorodina et al. ipTM matrices (row=nanobody, col=antigen, diagonal=real pair)."""
import numpy as np, pandas as pd, glob, os
from sklearn.metrics import roc_auc_score

for f in sorted(glob.glob("/home/hackathon/guled/denovo/data/iptm/iptm_confidence_scores/*_matrix_clean.csv")):
    name = os.path.basename(f).replace("_matrix_clean.csv","")
    df = pd.read_csv(f, index_col=0)
    M = df.values.astype(float)
    rows, cols = list(df.index), list(df.columns)
    # real pair = same PDB id in row and col
    y, s = [], []
    for i, r in enumerate(rows):
        for j, c in enumerate(cols):
            v = M[i, j]
            if np.isnan(v): continue
            y.append(1 if str(r).strip().lower() == str(c).strip().lower() else 0)
            s.append(v)
    y, s = np.array(y), np.array(s)
    real, shuf = s[y==1], s[y==0]
    auc = roc_auc_score(y, s)
    # how often does a real pair beat a random shuffled pair's score at 5% FPR
    thr95 = np.quantile(shuf, 0.95)
    tpr95 = (real > thr95).mean()
    print(f"{name:8s} shape={M.shape} real={len(real):4d} shuf={len(shuf):6d} "
          f"AUC={auc:.3f}  median real={np.median(real):.3f} shuf={np.median(shuf):.3f}  "
          f"TPR@5%FPR={tpr95:.2f} (ipTM>{thr95:.3f})")
