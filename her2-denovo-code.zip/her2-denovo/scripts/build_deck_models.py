"""Deck: four folding models compared on identical designs, plus top-20 candidates."""
import sys; sys.path.insert(0, "/home/hackathon/guled/denovo/scripts")
from _deck_common import *   # noqa
import pandas as pd

top = pd.read_csv("/home/hackathon/guled/denovo/results/top20.csv")

# ---------------------------------------------------------------- 1 title
s = slide(dark=True)
tb(s, 0.9, 2.0, 11.5, 1.4, "Which folding model can check a design?", size=46, bold=True,
   color=WH, font=HEAD)
tb(s, 0.9, 3.35, 11.5, 0.9,
   "Boltz-2, Protenix-v2, Mol-1 base and Protenix-v1 on the same 12 designs",
   size=20, color=MINT)
tb(s, 0.9, 4.5, 11.5, 1.2, [
   ("Headline: three of four models report a confident interface while docking the antibody 21 to 55 A", 15, False, C(0xCF,0xDE,0xE0)),
   ("away from the designed pose. Confidence scores cannot detect this. Geometry can.", 15, False, C(0xCF,0xDE,0xE0))], space_after=5)
tb(s, 0.9, 6.3, 11.5, 0.5, "HER2 de novo design  ·  14 November 2026", size=13, color=GREY)

# ---------------------------------------------------------------- 2 the comparison
s = slide()
title(s, "Four models, identical inputs",
      sub="Same 12 designs, same HER2 template, one seed each")
rows = [["Model", "HER2 fit", "Binder pose", "Epitope overlap", "ipTM", "min_ipae", "Verdict"],
        ["Boltz-2", "0.52 A", "2.4 A", "0.83", "0.952", "0.328", "USE"],
        ["Mol-1 base", "0.82 A", "21.0 A", "0.00", "0.712", "0.373", "exclude"],
        ["Protenix-v2", "5.78 A", "31.0 A", "0.21", "0.660", "0.504", "exclude"]]
table(s, 0.7, 2.25, 11.9, rows, [2.4,1.4,1.4,1.7,1.1,1.3,1.3], fs=12, rowh=0.40)
tb(s, 0.7, 4.65, 11.9, 0.4,
   "Medians over the same 12 designs. Both non-Boltz models are excluded on pose and epitope; Protenix-v2 additionally distorts the target.", size=11, color=GREY)
card(s, 0.7, 5.15, 5.9, 1.65, fill=C(0xE8,0xF4,0xF2))
tb(s, 1.0, 5.4, 5.3, 1.25, [
    ("They build the target correctly", 15, True, DK),
    ("Mol-1 and OpenFold3 reproduce HER2 domain IV to 0.68-0.83 A. The failure is not protein folding - it is where they put the antibody.", 12, False, GREY)], space_after=5)
card(s, 6.75, 5.15, 5.85, 1.65, fill=C(0xFC,0xEC,0xE8))
tb(s, 7.05, 5.4, 5.25, 1.25, [
    ("Epitope overlap 0.00", 15, True, WARN),
    ("Mol-1 and OpenFold3 share not one HER2 contact residue with the design. They found a different site entirely.", 12, False, GREY)], space_after=5)

# ---------------------------------------------------------------- 3 the trap
s = slide(dark=True)
title(s, "Every model passes the oracle. Two are wrong.", dark=True,
      sub="The antibody pass criterion is interface PAE <= 2.0 A")
for i, (m, ipae, pose, col) in enumerate([
        ("Boltz-2", "0.328", "2.4 A", MINT),
        ("Mol-1 base", "0.373", "21.0 A", WARN),
        ("Protenix-v2", "0.504", "31.0 A", WARN)]):
    x = 0.7 + i*4.12
    card(s, x, 2.3, 3.85, 2.5, fill=C(0x06,0x3B,0x43), edge=col)
    tb(s, x+0.3, 2.55, 3.2, 0.4, m, size=16, bold=True, color=WH, font=HEAD)
    tb(s, x+0.3, 3.05, 3.2, 0.55, ipae, size=32, bold=True, color=col, font=HEAD)
    tb(s, x+0.3, 3.65, 3.2, 0.4, "min_ipae (passes <= 2.0)", size=11, color=C(0x9F,0xB6,0xB9))
    tb(s, x+0.3, 4.12, 3.2, 0.5, pose, size=22, bold=True, color=WH, font=HEAD)
    tb(s, x+0.3, 4.55, 3.2, 0.3, "from designed pose", size=11, color=C(0x9F,0xB6,0xB9))
card(s, 0.7, 5.1, W-1.4, 1.75, fill=C(0x06,0x3B,0x43), edge=TEAL)
tb(s, 1.0, 5.35, W-2.0, 1.35, [
    ("Across models, confidence tracks pose fidelity: ipae 0.328 / 0.373 / 0.504 orders exactly as 2.4 / 21 / 31 A.", 13, False, MINT),
    ("But every value clears the 2.0 A threshold, so the criterion cannot reject the two wrong answers.", 13, False, C(0xCF,0xDE,0xE0)),
    ("ipTM orders the models the same way (0.952 / 0.712 / 0.660), and within a model it is the", 13, False, C(0xCF,0xDE,0xE0)),
    ("better of the two for ranking designs. The failure here is the fixed threshold, not the metrics.", 13, False, C(0xCF,0xDE,0xE0))], space_after=6)

# ---------------------------------------------------------------- 4 caveat
s = slide()
title(s, "What pose agreement does and does not prove",
      sub="The honest reading of the Boltz-2 result")
card(s, 0.7, 2.2, 5.9, 2.5, edge=WARN)
tb(s, 1.0, 2.45, 5.3, 2.1, [
    ("The template contains the answer", 16, True, WARN),
    ("refold-prepare writes a template holding all four chains: light chain, 110 of 120 heavy-chain residues, and HER2.", 12, False, GREY),
    ("Only the 10 designed CDRH3 residues are withheld. The antibody's position relative to HER2 is given.", 12, False, GREY),
    ("So pose RMSD measures template adherence. Boltz-2 agreeing is not independent confirmation that the binder binds there.", 12, False, WARN)], space_after=5)
card(s, 6.75, 2.2, 5.85, 2.5, edge=TEAL)
tb(s, 7.05, 2.45, 5.25, 2.1, [
    ("But the disagreement is still information", 16, True, TEAL),
    ("Both were shown the designed complex as a template and still moved the antibody 21-31 A away.", 12, False, GREY),
    ("Either they cannot handle this construct, or they do not believe the antibody belongs at that site.", 12, False, GREY),
    ("Those two readings have very different consequences, and the scores cannot tell them apart.", 12, False, TEAL)], space_after=5)
card(s, 0.7, 4.95, W-1.4, 1.85, fill=C(0xE8,0xF4,0xF2))
tb(s, 1.0, 5.2, W-2.0, 1.45, [
    ("The control that settles it, and has not been run", 15, True, DK),
    ("Fold the native trastuzumab-HER2 complex through the identical pipeline. Its structure is known (PDB 1N8Z).", 12, False, GREY),
    ("Boltz-2 passes it: trastuzumab's own loop lands on the real 1N8Z epitope at overlap 1.00 and pose 2.17 A. HER2 is split into chains C and D at", 12, False, GREY),
    ("its unresolved 581-590 loop and D carries two of the four hotspots, which is where Protenix-v2 in particular comes apart.", 12, False, GREY)], space_after=5)

# ---------------------------------------------------------------- 5 which is best
s = slide()
title(s, "Which model to use", sub="And what each one is good for")
items = [("Boltz-2", "The only usable checker here", 
          "Holds the template assembly (0.52 A), keeps 0.83 epitope overlap, and its pass criteria were calibrated this way. Use it - but read pose agreement as adherence, not proof.", MINT),
         ("Mol-1 base", "The more dangerous failure",
          "Builds HER2 to 0.82 A and reports the better ipae of the two failures (0.373), yet shares zero epitope. It looks right and is not.", WARN),
         ("Protenix-v2", "Fails on the construct",
          "Also distorts HER2 itself (5.78 A), misplacing the 17-residue D fragment that carries two of the four hotspots.", WARN)]
for i, (name, verdict, body, col) in enumerate(items):
    y = 2.3 + i*1.5
    card(s, 0.7, y, W-1.4, 1.25)
    bar = s.shapes.add_shape(MSO_SHAPE.OVAL, In(0.95), In(y+0.24), In(0.36), In(0.36))
    bar.fill.solid(); bar.fill.fore_color.rgb = col; bar.line.fill.background()
    bar.shadow.inherit = False
    tb(s, 1.48, y+0.14, 2.6, 0.32, name, size=14, bold=True, color=DK, font=HEAD)
    tb(s, 1.48, y+0.46, 2.6, 0.32, verdict, size=10.5, color=col)
    tb(s, 4.25, y+0.16, 8.1, 0.6, body, size=11.5, color=GREY, line=1.08)
tb(s, 0.7, 6.95, W-1.4, 0.4,
   "Ranking therefore rests on one model, Boltz-2. That is the main weakness of this result.", size=12, bold=True, color=WARN)


# ---------------------------------------------------------------- metric choice
s = slide()
title(s, "Which confidence metric to rank on",
      sub="Within Boltz-2, all 89 folded designs - not the pre-filtered shortlist")
rows = [["Metric", "vs epitope overlap", "vs pose RMSD", "vs P(high binder)", "Spread (CV)"],
        ["ipTM", "+0.584", "-0.498", "+0.156 (n.s.)", "0.105"],
        ["min_ipae", "-0.525", "+0.481", "-0.170 (n.s.)", "0.148"],
        ["epitope overlap", "-", "-", "+0.304", "0.543"],
        ["P(high binder)", "+0.304", "-", "-", "0.667"]]
table(s, 0.7, 2.25, 11.9, rows, [2.8,2.2,1.9,2.2,1.5], fs=12, rowh=0.44)
card(s, 0.7, 4.4, 5.9, 1.85, edge=TEAL)
tb(s, 1.0, 4.62, 5.3, 1.5, [
    ("ipTM leads, ipae second", 16, True, DK),
    ("For \"did the refold land on the interface we designed\", ipTM is the stronger of the two (+0.584 vs -0.525, both p < 1e-06).", 12, False, GREY),
    ("Rank on ipTM first, ipae second - on a set where they still vary.", 12, False, TEAL)], space_after=5)
card(s, 6.75, 4.4, 5.85, 1.85, edge=WARN)
tb(s, 7.05, 4.62, 5.25, 1.5, [
    ("A correction to an earlier claim", 16, True, WARN),
    ("We reported ipTM as flat (0.950-0.968). That was measured on a shortlist already gated at pose <= 10 A and epitope >= 0.2 - gates that remove the variance ipTM tracks.", 12, False, GREY),
    ("On all 89 designs ipTM runs 0.623-0.968. Range restriction, self-inflicted.", 12, False, WARN)], space_after=5)
card(s, 0.7, 6.4, W-1.4, 0.85, fill=C(0xE8,0xF4,0xF2))
tb(s, 1.0, 6.6, W-2.0, 0.5,
   [("Settled by the controls overleaf: against MEASURED binding, ipTM reaches AUC 0.867 (p=0.015) while epitope overlap falls to 0.289, below chance. Rank on ipTM; use geometry to reject, not to rank.", 12, False, DK)])


# ---------------------------------------------------------------- controls
s = slide()
title(s, "Ground truth: measured binders vs non-binders",
      sub="Trastuzumab + 8 FACS-measured binders + 8 measured non-binders, matched on edit distance. Boltz-2.")
card(s, 0.7, 2.15, W-1.4, 1.0, fill=C(0xE4,0xF1,0xEE))
tb(s, 1.0, 2.35, W-2.0, 0.65, [
    ("Positive control passes. Trastuzumab's own WGGDGFYAMD, folded from sequence: epitope overlap 1.00 against the real 1N8Z", 13, True, DK),
    ("epitope, pose 2.17 A, HER2 fit 0.49 A. The template withholds the CDRH3, so Boltz-2 places the loop itself - not a copy.", 13, False, GREY)], space_after=5)
rows = [["Metric", "binders (n=8)", "non-binders (n=8)", "AUC", "p", "Verdict"],
        ["ipTM", "0.950", "0.923", "0.867", "0.015", "ranks"],
        ["pTM", "0.961", "0.944", "0.820", "0.035", "ranks"],
        ["ranking score", "0.961", "0.951", "0.656", "0.328", "no"],
        ["pLDDT", "96.4", "95.8", "0.594", "0.574", "no"],
        ["pose RMSD", "2.32 A", "2.33 A", "0.484", "0.959", "no"],
        ["epitope vs 1N8Z", "0.814", "0.903", "0.289", "0.156", "below chance"]]
table(s, 0.7, 3.4, 11.9, rows, [2.6,1.9,2.1,1.3,1.1,1.8], fs=12, rowh=0.355)
card(s, 0.7, 5.95, 5.9, 1.1, edge=MINT)
tb(s, 1.0, 6.12, 5.3, 0.8, [
    ("ipTM ranks - AUC 0.867, p = 0.015", 14, True, DK),
    ("The only metric to clear significance, on edit-distance-matched controls. pTM follows at 0.820.", 11.5, False, GREY)], space_after=4)
card(s, 6.75, 5.95, 5.85, 1.1, edge=WARN)
tb(s, 7.05, 6.12, 5.25, 0.8, [
    ("Epitope overlap does not - AUC 0.289", 14, True, DK),
    ("Below chance. With the framework template-fixed, every real sequence lands near the trastuzumab epitope. A gate, not a ranker.", 11.5, False, GREY)], space_after=4)
tb(s, 0.7, 7.15, W-1.4, 0.3,
   "n = 8 per class: a direction, not a precise AUC; the gap to pTM is not meaningful. One seed each. Protenix-v1 on the same controls still folding.",
   size=10.5, color=GREY)

# ---------------------------------------------------------------- 6 top 20
s = slide()
title(s, "Top 20 candidates", sub="Boltz-2 confidence; all passed novelty, pose <= 10 A and epitope >= 0.2")
rows = [["#", "CDRH3", "Ed", "ipTM", "ipae", "pLDDT", "Pose", "Epi", "P(high)", "pKD"]]
for _, r in top.iterrows():
    rows.append([int(r["rank"]), r.cdrh3, int(r.edit_from_tz), f"{r.iptm:.3f}",
                 f"{r.min_ipae:.3f}", f"{r.binder_plddt:.1f}", f"{r.pose_rmsd:.2f}",
                 f"{r.epitope:.2f}", f"{r.p_high_binder:.2f}", f"{r.pred_pkd:.2f}"])
table(s, 0.7, 2.1, 11.9, rows, [0.5,2.1,0.6,1.0,1.0,1.0,0.9,0.8,1.0,0.9], fs=9.5, rowh=0.235)
tb(s, 0.7, 7.0, 11.9, 0.35,
   "ipTM 0.950-0.968 and ipae 0.301-0.331 here only because this shortlist is already gated on pose and epitope; on all 89 designs ipTM runs 0.623-0.968. Ed = edits vs trastuzumab.",
   size=10.5, color=GREY)

# ---------------------------------------------------------------- 7 the four picks
s = slide(dark=True)
title(s, "The four to make", dark=True,
      sub="Chosen on evidence that varies, not on confidence that does not")
picks = [("WGAQGFYSYD", "4 edits, 60% identity", "Epitope 1.00 on both measures, P(high) 0.98, pKD 9.0, pose 1.82 A. The only design that is top-3 on folding and highest on both sequence models.", MINT),
         ("STASVDYAMD", "6 edits, 40% identity", "Best pose in the whole set at 0.92 A, rank 1 on folding. A different CDRH3 cluster, and a different N-terminal motif (STASV vs WGGDG).", TEAL),
         ("WANGGFAAYG", "6 edits, 40% identity", "Epitope 1.00, P(high) 0.95, pKD 7.79. The strongest agreement between folding and sequence evidence outside the top two.", TEAL),
         ("YGYPSFYAYD", "5 edits, 50% identity", "P(high) 0.88, pKD 8.13. Replaces WGPPYFYAMD, which sat at exactly 70% identity - the filter's limit, with zero margin.", TEAL)]
for i, (cdr, ed, body, col) in enumerate(picks):
    x = 0.7 + (i % 2)*6.05
    y = 2.3 + (i // 2)*2.25
    card(s, x, y, 5.8, 2.0, fill=C(0x06,0x3B,0x43), edge=col)
    tb(s, x+0.3, y+0.2, 5.2, 0.45, cdr, size=22, bold=True, color=col, font=HEAD)
    tb(s, x+0.3, y+0.7, 5.2, 0.3, ed, size=11, color=C(0x9F,0xB6,0xB9))
    tb(s, x+0.3, y+1.05, 5.2, 0.85, body, size=12, color=C(0xCF,0xDE,0xE0), line=1.1)
tb(s, 0.7, 6.95, W-1.4, 0.4,
   "Four different CDRH3 clusters. Every pick has at least 1 position of margin on the <= 70% identity rule. Every number is a prediction; no lab data.",
   size=12, color=MINT)

prs.save("/home/hackathon/guled/denovo/deck/her2-folding-models.pptx")
print("saved", len(prs.slides._sldIdLst), "slides")
