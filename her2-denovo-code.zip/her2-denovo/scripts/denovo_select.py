"""Final selection, applied in this order:

  1. both gates: challenge novelty filter + canonical residues
  2. refold must land within POSE_MAX A of the pose it was designed in
     (a good min_ipae 40 A away is a different binding site, not ours)
  3. epitope overlap with the designed contact set >= EPI_MIN
  4. rank by averaged binding percentile across pose-faithful folding models
  5. at most one design per CDRH3 cluster, so we do not submit six variants of one idea

Pose-faithful models are chosen by evidence, not assumption: a model whose refolds do not
reproduce the designed HER2 assembly is excluded and the reason is printed.
"""
import pandas as pd, numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from models import FOLD_MODELS, keep

POSE_MAX, EPI_MIN, HER2_FIT_MAX = 10.0, 0.20, 2.0
MODEL_POSE_MAX, MODEL_EPI_MIN = 5.0, 0.20   # model-level pose fidelity
R = "/home/hackathon/guled/denovo/results/"

des = pd.read_csv(R + "designs_scored.csv")
fold = pd.read_csv(R + "refold_all.csv")
pose = pd.read_csv(R + "pose_epitope.csv")
pose = pose[pose.fold_model.isin(FOLD_MODELS)]
fold = fold[fold.fold_model.isin(FOLD_MODELS)]

# --- which folding models actually reproduce the designed assembly? ---
fit = pose.groupby("fold_model").agg(her2_fit=("her2_align_rmsd", "median"),
                                     pose=("pose_rmsd_binder", "median"),
                                     epi=("epitope_jaccard", "median"), n=("run", "size"))
print("folding models, pose fidelity (median):")
def why(r):
    if r.her2_fit > HER2_FIT_MAX: return "EXCLUDE: does not rebuild the designed HER2 assembly"
    if r.pose > MODEL_POSE_MAX:   return f"EXCLUDE: docks the binder {r.pose:.0f} A from the designed pose"
    if r.epi < MODEL_EPI_MIN:     return "EXCLUDE: shares no epitope with the design"
    return "USE"
for m, r in fit.iterrows():
    print(f"  {m:16s} n={int(r.n):3d} HER2 fit={r.her2_fit:5.2f} A  binder pose={r.pose:6.2f} A  "
          f"epitope={r.epi:.2f}  -> {why(r)}")
keep_models = [m for m, r in fit.iterrows() if why(r) == "USE"]
if not keep_models: sys.exit("no folding model reproduces the designed assembly")

# --- join design scores, fold scores and pose/epitope on (run, example_id) ---
pose["key"] = pose.run + "|" + pose.example_id
des["key"] = des.run + "|" + des.example_id
f = fold[fold.fold_model.isin(keep_models)].copy()
# refold_all has no example_id; recover it via (run, cdrh3) -> example_id
m = des.drop_duplicates(["run", "cdrh3"])[["run", "cdrh3", "key"]]
f = f.merge(m, on=["run", "cdrh3"], how="left")
p = pose[pose.fold_model.isin(keep_models)]
f = f.merge(p[["key", "fold_model", "pose_rmsd_binder", "pose_rmsd_cdrh3",
               "epitope_jaccard", "epitope_vs_1n8z", "her2_align_rmsd"]],
            on=["key", "fold_model"], how="left")

# percentile within each folding model (low min_ipae is good)
f["pct"] = f.groupby("fold_model").min_ipae.rank(pct=True, ascending=False) * 100
agg = f.groupby("key").agg(
    n_models=("fold_model", "nunique"), avg_pct=("pct", "mean"),
    min_ipae=("min_ipae", "mean"), binder_plddt=("binder_plddt", "mean"),
    binder_ptm=("binder_ptm", "mean"),
    pose_rmsd=("pose_rmsd_binder", "max"),       # worst case across models
    epitope=("epitope_jaccard", "min"),
    epitope_1n8z=("epitope_vs_1n8z", "min"),
    her2_fit=("her2_align_rmsd", "max")).reset_index()
d = des.drop_duplicates("key").set_index("key")
agg = agg.join(d[["run", "cdrh3", "edit_from_tz", "p_high_binder", "pred_pkd",
                  "passes_challenge_filter", "canonical"]], on="key")

n0 = len(agg)
agg = agg[agg.passes_challenge_filter & agg.canonical]
n1 = len(agg)
agg = agg[agg.pose_rmsd <= POSE_MAX]; n2 = len(agg)
agg = agg[agg.epitope >= EPI_MIN];    n3 = len(agg)
print(f"\nfolded {n0} -> gates {n1} -> pose <= {POSE_MAX} A {n2} -> epitope >= {EPI_MIN} {n3}")

# CDRH3 clustering: single-linkage at Hamming <= 3, so near-variants collapse
def cluster(seqs, cut=3):
    lab, cid = {}, 0
    for s in seqs:
        hit = next((lab[t] for t in lab if len(t) == len(s)
                    and sum(a != b for a, b in zip(s, t)) <= cut), None)
        lab[s] = hit if hit is not None else cid
        if hit is None: cid += 1
    return lab

agg = agg.sort_values("avg_pct", ascending=False)
lab = cluster(agg.cdrh3.tolist())
agg["cluster"] = agg.cdrh3.map(lab)
final = agg.drop_duplicates("cluster")
print(f"{len(agg)} candidates in {agg.cluster.nunique()} CDRH3 clusters "
      f"-> {len(final)} after one-per-cluster\n")
cols = ["cdrh3", "run", "edit_from_tz", "avg_pct", "min_ipae", "binder_plddt",
        "pose_rmsd", "epitope", "epitope_1n8z", "p_high_binder", "pred_pkd", "n_models", "cluster"]
pd.set_option("display.width", 250)
print(final[cols].head(12).round(3).to_string(index=False))
final.to_csv(R + "final_selection.csv", index=False)
agg.to_csv(R + "final_ranking_gated.csv", index=False)
