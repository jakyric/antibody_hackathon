"""Can we rank designs by affinity, not just binding? Trains on the 190 SPR KD values.
Reports honest grouped cross-validation -- if it does not generalise, we do not use it."""
import numpy as np, pandas as pd, pickle
from sklearn.model_selection import GroupKFold, KFold
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import RandomForestRegressor
from scipy.stats import spearmanr

AA = "ACDEFGHIKLMNPQRSTVWY"; IDX = {a:i for i,a in enumerate(AA)}
TZ  = "WGGDGFYAMD"
D = "/home/hackathon/guled/denovo/data/"

s = pd.read_csv(D + "trastuzumab_her2_spr_all_768.csv")
# drop the unrelated antibody noted in the data README
s = s[s.cdrh3 != "ARDRIVDDYYYYGMDV"]
q = s[(s.binding_result == "quantified_binding") & s.kd_nM.notna()].copy()
q = q[q.cdrh3.str.len() == 10].copy()
q["pkd"] = -np.log10(q.kd_nM * 1e-9)          # higher = tighter
q = q.groupby("cdrh3", as_index=False).agg(pkd=("pkd","mean"))
print(f"{len(q)} distinct 10-mer CDRH3 with a measured KD; pKD {q.pkd.min():.2f}-{q.pkd.max():.2f}")

def onehot(seqs):
    X = np.zeros((len(seqs), 200), dtype=np.float32)
    for n, t in enumerate(seqs):
        for p, c in enumerate(t[:10]):
            if c in IDX: X[n, p*20 + IDX[c]] = 1
    return X

X, y = onehot(q.cdrh3), q.pkd.values
# group by trastuzumab-mutation pattern so near-identical loops stay in one fold
groups = [ "".join("1" if a!=b else "0" for a,b in zip(c,TZ)) for c in q.cdrh3 ]
gk = GroupKFold(n_splits=5)
for name, mk in [("ridge", lambda: RidgeCV(alphas=np.logspace(-2,3,20))),
                 ("rf", lambda: RandomForestRegressor(n_estimators=400, min_samples_leaf=3,
                                                      random_state=0, n_jobs=4))]:
    pred = np.zeros(len(y))
    for tr, te in gk.split(X, y, groups):
        m = mk().fit(X[tr], y[tr]); pred[te] = m.predict(X[te])
    rho = spearmanr(y, pred).statistic
    mae = np.abs(y - pred).mean()
    print(f"{name:6s} grouped 5-fold: spearman={rho:+.3f}  MAE={mae:.2f} log units "
          f"(predicting the mean would give MAE={np.abs(y-y.mean()).mean():.2f})")
    full = mk().fit(X, y)
    pickle.dump(full, open(f"/home/hackathon/guled/denovo/results/affinity_{name}.pkl","wb"))
# does edit distance from trastuzumab alone predict affinity?
ed = np.array([sum(a!=b for a,b in zip(c,TZ)) for c in q.cdrh3])
print(f"baseline: spearman(edit distance from trastuzumab, pKD) = {spearmanr(ed, y).statistic:+.3f}")
