"""Independent check: the binder classifier was trained on FACS classes. Does its score
track SPR-measured KD -- a different assay, mostly different sequences?"""
import numpy as np, pandas as pd, pickle
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
AA="ACDEFGHIKLMNPQRSTVWY"; IDX={a:i for i,a in enumerate(AA)}
D="/home/hackathon/guled/denovo/data/"
def onehot(seqs):
    X=np.zeros((len(seqs),200),dtype=np.float32)
    for n,s in enumerate(seqs):
        for p,c in enumerate(s[:10]):
            if c in IDX: X[n,p*20+IDX[c]]=1
    return X

m=pickle.load(open("/home/hackathon/guled/denovo/results/binder_lgbm.pkl","rb"))
facs=set(pd.read_csv(D+"tz_her2_facs_3classes_524346.csv",usecols=["cdrh3"]).cdrh3)
s=pd.read_csv(D+"trastuzumab_her2_spr_all_768.csv")
s=s[(s.cdrh3!="ARDRIVDDYYYYGMDV") & (s.cdrh3.str.len()==10)].copy()
s["p"]=m.predict_proba(onehot(s.cdrh3))[:,1]
s["in_facs"]=s.cdrh3.isin(facs)

q=s[(s.binding_result=="quantified_binding") & s.kd_nM.notna()].copy()
q["pkd"]=-np.log10(q.kd_nM*1e-9)
for label, sub in [("all SPR with KD", q), ("only loops NOT in the FACS screen", q[~q.in_facs])]:
    if len(sub)<10: continue
    print(f"{label}: n={len(sub)}  spearman(P(high), pKD)={spearmanr(sub.p, sub.pkd).statistic:+.3f}")

# does the classifier separate measurable binders from the ones SPR could not fit?
pos=s[s.binding_result=="quantified_binding"]; neg=s[s.binding_result=="no_reportable_kd"]
y=np.r_[np.ones(len(pos)),np.zeros(len(neg))]; p=np.r_[pos.p.values,neg.p.values]
print(f"quantified_binding ({len(pos)}) vs no_reportable_kd ({len(neg)}): AUC={roc_auc_score(y,p):.3f}")
ex=s[~s.in_facs]
pos,neg=ex[ex.binding_result=="quantified_binding"],ex[ex.binding_result=="no_reportable_kd"]
if len(pos)>5 and len(neg)>5:
    y=np.r_[np.ones(len(pos)),np.zeros(len(neg))]; p=np.r_[pos.p.values,neg.p.values]
    print(f"  same, excluding loops seen in the FACS screen ({len(pos)} vs {len(neg)}): AUC={roc_auc_score(y,p):.3f}")
# tightest binders
print("\ntop 5 SPR binders by measured KD and what the classifier says:")
print(q.nsmallest(5,"kd_nM")[["cdrh3","kd_nM","p","in_facs"]].to_string(index=False))
