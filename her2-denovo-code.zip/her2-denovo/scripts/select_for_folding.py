"""Build a pruned copy of a design run holding only chosen designs, so refold-prepare
and the folding models spend GPU time only on candidates our data likes.

Usage: select_for_folding.py <scored.csv> <out-design-dir> <n> [--runs run1,run2]
Selection: challenge filter must pass, then rank by P(high binder) from the FACS model,
tie-broken by interface H-bond count from co-generation.
"""
import pandas as pd, sys, os, shutil, json

RFD = "/home/hackathon/rfd4"

def main(scored_csv, out_dir, n, runs=None, exclude_folded=None):
    df = pd.read_csv(scored_csv)
    if runs: df = df[df.run.isin(runs)]
    if exclude_folded and os.path.exists(exclude_folded):
        done = set(pd.read_csv(exclude_folded).cdrh3.dropna())
        before = len(df); df = df[~df.cdrh3.isin(done)]
        print(f"excluding {before - len(df)} designs already folded")
    ok = df[df.passes_challenge_filter == True].copy()
    print(f"{len(df)} designs -> {len(ok)} pass the challenge filter "
          f"({ok.cdrh3.nunique()} distinct loops)")
    # combined rank: both rankers are validated, so average their ranks
    ok["rank_binder"] = ok.p_high_binder.rank(pct=True)
    ok["rank_aff"] = ok.pred_pkd.rank(pct=True) if "pred_pkd" in ok else 0.5
    ok["combined"] = (ok.rank_binder + ok.rank_aff) / 2
    tie = "hbond_pairs" if "hbond_pairs" in ok.columns and ok.hbond_pairs.notna().any() else "combined"
    ok = ok.sort_values(tie, ascending=False).drop_duplicates("cdrh3")
    ok = ok.sort_values("combined", ascending=False).head(n)
    print(f"selected {len(ok)}: P(high binder) {ok.p_high_binder.min():.3f}-{ok.p_high_binder.max():.3f}, "
          f"pred pKD {ok.pred_pkd.min():.2f}-{ok.pred_pkd.max():.2f}")

    # group selections by their source design run, prune a copy of each
    made = []
    for run, grp in ok.groupby("run"):
        src = f"{RFD}/runs/{run}/design"
        dst = f"{RFD}/{out_dir}/{run}/design"
        if os.path.exists(dst): shutil.rmtree(dst)
        os.makedirs(dst + "/generation/inference_metrics", exist_ok=True)
        for f in ("config.json",):
            if os.path.exists(f"{src}/{f}"): shutil.copy(f"{src}/{f}", f"{dst}/{f}")
        keep = set(grp.example_id)
        for eid in keep:
            s = f"{src}/generation/inference_samples/{eid}"
            if os.path.isdir(s): shutil.copytree(s, f"{dst}/generation/inference_samples/{eid}")
        mp = f"{src}/generation/inference_metrics/per_example_metrics.csv"
        if os.path.exists(mp):
            m = pd.read_csv(mp)
            m[m.example_id.isin(keep)].to_csv(
                f"{dst}/generation/inference_metrics/per_example_metrics.csv", index=False)
        else:
            print(f"  note: {run} still running, no per_example_metrics yet", file=sys.stderr)
        agg = f"{src}/generation/inference_metrics/aggregated_metrics.csv"
        if os.path.exists(agg):
            shutil.copy(agg, f"{dst}/generation/inference_metrics/aggregated_metrics.csv")
        # rebuild the manifest refold-prepare requires; it lists only real pruned files
        src_res = f"{src}/result.json"
        res = json.load(open(src_res)) if os.path.exists(src_res) else {
            "provenance": {"module": {"name": "apheris-rfd4-proteina", "version": "0.3.0"}},
            "schema_version": "foundry.cli.v1", "task": "design", "result": {}}
        designs = sorted(f"generation/inference_samples/{e}/{e}_generated.cif" for e in keep)
        missing = [d for d in designs if not os.path.exists(f"{dst}/{d}")]
        assert not missing, f"manifest would reference missing files: {missing}"
        res["result"] = {"artifacts": "generation", "designs": designs,
                         "log": "generation.log",
                         "metrics": "generation/inference_metrics/per_example_metrics.csv"}
        res.setdefault("provenance", {})["pruned_from"] = src
        json.dump(res, open(f"{dst}/result.json", "w"), indent=2)
        open(f"{dst}/generation.log", "a").close()
        print(f"  {run}: {len(keep)} designs -> {dst}")
        made.append(dst)
    ok.to_csv(f"/home/hackathon/guled/denovo/results/selected_for_folding.csv", index=False)
    print("\n".join(made))

if __name__ == "__main__":
    a = sys.argv[1:]
    runs = None
    if "--runs" in a:
        i = a.index("--runs"); runs = a[i+1].split(","); a = a[:i] + a[i+2:]
    exc = None
    if "--exclude-folded" in a:
        i = a.index("--exclude-folded"); exc = a[i+1]; a = a[:i] + a[i+2:]
    main(a[0], a[1], int(a[2]), runs, exc)
