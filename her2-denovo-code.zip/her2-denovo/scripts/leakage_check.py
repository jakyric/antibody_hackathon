"""Is the 0.99 AUC real or leakage? Checks (1) sequence overlap between splits,
(2) how close test sequences sit to the training set, (3) whether edit distance
from trastuzumab alone explains the label, (4) AUC restricted to far-from-train test seqs."""
import numpy as np, pandas as pd, pickle
from sklearn.metrics import roc_auc_score
D = "/home/hackathon/guled/denovo/data/splits/"
AA = "ACDEFGHIKLMNPQRSTVWY"; IDX = {a:i for i,a in enumerate(AA)}
tr, te = pd.read_csv(D+"train.csv"), pd.read_csv(D+"test.csv")

print("1) exact sequence overlap train/test:", len(set(tr.seq) & set(te.seq)))
print("   cluster overlap:", len(set(tr.cluster_centre) & set(te.cluster_centre)))

def onehot(seqs):
    X = np.zeros((len(seqs), 200), dtype=np.float32)
    for n, s in enumerate(seqs):
        for p, c in enumerate(s[:10]):
            if c in IDX: X[n, p*20+IDX[c]] = 1
    return X

Xtr = onehot(tr.seq)
rng = np.random.default_rng(0)
samp = rng.choice(len(te), 3000, replace=False)
Xte = onehot(te.seq.values[samp])
# hamming = 10 - number of matching positions; matches = dot product of one-hots
mind = np.empty(len(Xte), dtype=np.int16)
for i in range(0, len(Xte), 250):
    blk = Xte[i:i+250] @ Xtr.T           # matching positions
    mind[i:i+250] = (10 - blk.max(axis=1)).astype(np.int16)
print("2) min Hamming distance from a test sequence to the nearest training sequence:")
print("  ", pd.Series(mind).value_counts().sort_index().to_dict())

m = pickle.load(open("/home/hackathon/guled/denovo/results/binder_lgbm.pkl","rb"))
p = m.predict_proba(Xte)[:,1]; y = te.label.values[samp]
print(f"3) AUC on this 3000-sequence sample: {roc_auc_score(y, p):.4f}")
for cut in (2,3,4,5):
    sel = mind >= cut
    if sel.sum() > 50 and 0 < y[sel].mean() < 1:
        print(f"   test seqs >= {cut} mutations from ANY training seq: n={sel.sum():5d} "
              f"pos rate={y[sel].mean():.3f} AUC={roc_auc_score(y[sel], p[sel]):.4f}")
TZ="WGGDGFYAMD"
ed = te.edit_distance.values[samp]
print(f"4) AUC using edit distance from trastuzumab alone: {roc_auc_score(y, -ed):.4f}")
