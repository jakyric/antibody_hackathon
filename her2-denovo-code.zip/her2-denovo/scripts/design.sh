#!/usr/bin/env bash
# De novo CDRH3 co-generation against HER2 with RFD4-Proteina.
# Usage: design.sh <tag> <image-suffix> <n> <seed> [extra flags...]
set -euo pipefail
cd /home/hackathon/rfd4
Q=quay.io/apheris/oslo-hackathon
TAG=$1; IMG=$2; N=$3; SEED=$4; shift 4
OUT=runs/$TAG/design
run=(docker run --rm --gpus all --shm-size 16g --user "$(id -u):$(id -g)"
     -e HOME=/tmp -v /etc/passwd:/etc/passwd:ro -v "$PWD:/work" -w /work)
rm -rf "$OUT"
"${run[@]}" "$Q:apheris-rfd4-proteina-v0.3.0-$IMG" module-run design \
  --input Data/12-her2/her2_cdrh3.yaml --output "$OUT" \
  --num-replicates "$N" --seed "$SEED" --recycle-strategy high/front_loaded "$@"
echo "DESIGN_DONE $TAG"
