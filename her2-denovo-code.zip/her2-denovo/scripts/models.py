"""The folding models this project uses. Nothing else is read or reported.

Keys are the --model labels refold-score takes and the folder names the
prediction outputs land in.
"""
FOLD_MODELS = ("boltz2", "protenix-v2", "mol1-base")

IMAGES = {
    "boltz2":      "apheris-boltz-v1.3.0-boltz2",
    "protenix-v2": "apheris-protenix-v1.3.0-v2",
    "mol1-base":   "apheris-mol1-v1.3.0-base",
}

def keep(model: str) -> bool:
    return model in FOLD_MODELS
