"""P(high HER2 binder) from a 10-mer CDRH3. Trained on Chinery/Mehta FACS screen,
clonotype split (held-out sequence families), label 1 = high binder."""
import numpy as np, pandas as pd, pickle, json
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.linear_model import LogisticRegression
import lightgbm as lgb, sys
sys.stdout.reconfigure(line_buffering=True)

AA = "ACDEFGHIKLMNPQRSTVWY"
IDX = {a: i for i, a in enumerate(AA)}
D = "/home/hackathon/guled/denovo/data/splits/"

def onehot(seqs):
    X = np.zeros((len(seqs), 10 * 20), dtype=np.float32)
    for n, s in enumerate(seqs):
        for p, c in enumerate(s[:10]):
            if c in IDX: X[n, p * 20 + IDX[c]] = 1
    return X

tr, va, te = (pd.read_csv(D + f) for f in ("train.csv", "val.csv", "test.csv"))
print({k: (len(d), d.label.mean().round(3)) for k, d in [("train",tr),("val",va),("test",te)]})

Xtr, ytr = onehot(tr.seq), tr.label.values
Xva, yva = onehot(va.seq), va.label.values
Xte, yte = onehot(te.seq), te.label.values

res = {}
# baseline: position-wise logistic regression
lr = LogisticRegression(max_iter=2000, C=1.0).fit(Xtr, ytr)
res["logreg"] = (roc_auc_score(yva, lr.predict_proba(Xva)[:,1]),
                 roc_auc_score(yte, lr.predict_proba(Xte)[:,1]))

# LightGBM: can learn position interactions (epistasis)
m = lgb.LGBMClassifier(n_estimators=800, learning_rate=0.08, num_leaves=63,
                       min_child_samples=50, subsample=0.8, subsample_freq=1,
                       colsample_bytree=0.8, n_jobs=8, verbose=-1)
m.fit(Xtr, ytr, eval_set=[(Xva, yva)], eval_metric="auc",
      callbacks=[lgb.early_stopping(50, verbose=True), lgb.log_evaluation(50)])
pv, pt = m.predict_proba(Xva)[:,1], m.predict_proba(Xte)[:,1]
res["lgbm"] = (roc_auc_score(yva, pv), roc_auc_score(yte, pt))
print("best_iter", m.best_iteration_)
for k,(a,b) in res.items(): print(f"{k:8s} val AUC={a:.4f}  test AUC={b:.4f}")
print(f"lgbm test AP={average_precision_score(yte, pt):.4f} (base rate {yte.mean():.3f})")

# precision in the top slice -- what matters when we only keep a handful of designs
for q in (0.01, 0.05, 0.10):
    thr = np.quantile(pt, 1-q)
    print(f"  top {q*100:4.1f}% of test by score: precision(high binder)={yte[pt>=thr].mean():.3f}")

pickle.dump(m, open("/home/hackathon/guled/denovo/results/binder_lgbm.pkl","wb"))
json.dump({k: {"val_auc": a, "test_auc": b} for k,(a,b) in res.items()},
          open("/home/hackathon/guled/denovo/results/binder_metrics.json","w"), indent=2)
