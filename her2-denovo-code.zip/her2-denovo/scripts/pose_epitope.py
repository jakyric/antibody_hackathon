"""Two checks the refold scores alone do not give you:

  pose_rmsd      superimpose the refold on HER2 (chains C+D), then measure how far the
                 binder moved. A good min_ipae at the wrong place is a different binding
                 site, not ours.
  epitope_jaccard  HER2 residues contacted by CDRH3 in the refold vs in the design.
  epitope_vs_1n8z  the same, against trastuzumab's real epitope in PDB 1N8Z.

HER2 keeps its own numbering (C 489-580, D 591-607) in both design and refold outputs,
verified before use -- no offset is applied, and a mismatch raises instead of scoring 0.
"""
import gemmi, numpy as np, pandas as pd, glob, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from models import FOLD_MODELS, keep

CDRH3 = range(99, 109)          # chain B, this file's numbering
TARGET = ("C", "D")
CUT = 5.0

def load(p):
    st = gemmi.read_structure(p); st.setup_entities(); st.remove_alternative_conformations()
    return st[0]

def ca(model, chains, resids=None):
    out = {}
    for ch in model:
        if ch.name not in chains: continue
        for r in ch:
            if resids is not None and r.seqid.num not in resids: continue
            a = r.find_atom("CA", "*")
            if a: out[(ch.name, r.seqid.num)] = np.array(a.pos.tolist())
    return out

def contacts(model):
    """HER2 residues within CUT of any CDRH3 atom."""
    cdr = [a.pos for ch in model if ch.name == "B" for r in ch
           if r.seqid.num in CDRH3 for a in r]
    if not cdr: return set()
    hit = set()
    for ch in model:
        if ch.name not in TARGET: continue
        for r in ch:
            if any(a.pos.dist(c) <= CUT for a in r for c in cdr):
                hit.add((ch.name, r.seqid.num))
    return hit

def jac(a, b):
    return len(a & b) / len(a | b) if (a or b) else np.nan

def pose_rmsd(des, ref):
    """Align on HER2, report how far the binder and its CDRH3 moved."""
    d, r = ca(des, TARGET), ca(ref, TARGET)
    keys = sorted(set(d) & set(r))
    if len(keys) < 3:
        raise ValueError(f"only {len(keys)} shared HER2 residues -- numbering mismatch")
    P = gemmi.Position
    sup = gemmi.superpose_positions([P(*d[k]) for k in keys], [P(*r[k]) for k in keys])
    tr = sup.transform
    out = {"her2_align_rmsd": sup.rmsd, "n_her2_aligned": len(keys)}
    for lbl, resids in (("binder", None), ("cdrh3", set(CDRH3))):
        dd, rr = ca(des, ("B",), resids), ca(ref, ("B",), resids)
        ks = sorted(set(dd) & set(rr))
        if not ks: out[f"pose_rmsd_{lbl}"] = np.nan; continue
        moved = np.array([tr.apply(P(*rr[k])).tolist() for k in ks])
        fixed = np.array([dd[k] for k in ks])
        out[f"pose_rmsd_{lbl}"] = float(np.sqrt(((moved - fixed) ** 2).sum(1).mean()))
    return out

def main():
    # trastuzumab's real epitope
    ref_ep = contacts(load("/home/hackathon/rfd4/Data/12-her2/her2_fv_1n8z.cif"))
    print(f"1N8Z trastuzumab CDRH3 epitope: {len(ref_ep)} HER2 residues "
          f"{sorted(n for _, n in ref_ep)}", file=sys.stderr)

    rows = []
    for pred in sorted(glob.glob("/home/hackathon/rfd4/runs*/*/*/*/seed_*/*_model.cif")
                     + glob.glob("/home/hackathon/rfd4/runs*/*/*/*/*_model.cif")):
        parts = pred.split("/")
        try: i = parts.index("rfd4")
        except ValueError: continue
        base, run = parts[i + 1], parts[i + 2]          # runs-selected|runs-batch2, run tag
        # the prediction folder is named by the --model key, whatever it is
        model = parts[i + 3] if len(parts) > i + 3 else None
        if model is None or not keep(model):      # three models, nothing else
            continue
        model_dir = [model]
        eid = re.sub(r"_seed_\d+.*$", "", os.path.basename(pred)).replace("_model.cif", "")
        des_p = f"/home/hackathon/rfd4/{base}/{run}/design/generation/inference_samples/{eid}/{eid}_generated.cif"
        if not os.path.exists(des_p): continue
        try:
            des, ref = load(des_p), load(pred)
            m = pose_rmsd(des, ref)
            de, re_ = contacts(des), contacts(ref)
            m.update(epitope_jaccard=jac(de, re_), epitope_vs_1n8z=jac(re_, ref_ep),
                     n_contacts_design=len(de), n_contacts_refold=len(re_))
            m.update(batch=base, run=run, example_id=eid, fold_model=model_dir[0])
            rows.append(m)
        except Exception as e:
            print(f"  skip {run}/{eid}/{model_dir[0]}: {e}", file=sys.stderr)

    df = pd.DataFrame(rows)
    df.to_csv("/home/hackathon/guled/denovo/results/pose_epitope.csv", index=False)
    print(f"\n{len(df)} refolds analysed")
    if len(df):
        pd.set_option("display.width", 220)
        print(df.groupby("fold_model")[["pose_rmsd_binder","pose_rmsd_cdrh3",
              "epitope_jaccard","epitope_vs_1n8z","her2_align_rmsd"]].describe().T.round(2).to_string())


if __name__ == "__main__":
    main()
