"""Ground-truth control set: fold CDRH3 loops whose HER2 binding was MEASURED.

Positives: trastuzumab itself (WGGDGFYAMD, PDB 1N8Z) + FACS 'high' binders.
Negatives: FACS 'low' binders -- measured non-binders, matched to the positives
on edit distance from trastuzumab so the comparison is not confounded by it.

Writes a queries.json the folding models take directly, reusing the same HER2
template as every other refold in this project.
"""
import json, pandas as pd, numpy as np, shutil, os, sys

N_PER = 8
PREP = "/home/hackathon/rfd4/runs-selected/her2-explore-s1/prepared/holo"
OUT  = "/home/hackathon/rfd4/controls"
TZ   = "WGGDGFYAMD"
FACS = "/home/hackathon/guled/denovo/data/tz_her2_facs_3classes_524346.csv"

d = pd.read_csv(FACS, usecols=["cdrh3", "binding_class", "edit_distance"])
rng = np.random.default_rng(0)
# match on edit distance: take the distances where both classes are well populated
band = d[d.edit_distance.between(5, 8)]
rows = [dict(cdrh3=TZ, truth="native", edit_distance=0)]
for ed in (5, 6, 7, 8):
    sub = band[band.edit_distance == ed]
    for cls, truth in (("high", "binder"), ("low", "nonbinder")):
        pick = sub[sub.binding_class == cls].sample(N_PER // 4, random_state=int(ed))
        for c in pick.cdrh3:
            rows.append(dict(cdrh3=c, truth=truth, edit_distance=ed))
ctl = pd.DataFrame(rows).drop_duplicates("cdrh3").reset_index(drop=True)
ctl["query_id"] = [f"ctl_{i:02d}_{r.truth}" for i, r in ctl.iterrows()]
print(ctl.truth.value_counts().to_dict())

base = json.load(open(f"{PREP}/queries.json"))
proto = base["queries"][0]
vh = next(c["sequence"] for c in proto["chains"] if c["chain_id"] == "B")
pre, post = vh.split("YYCSR")[0] + "YYCSR", "YWGQGTLVTVSS"
assert len(pre) + 10 + len(post) == len(vh), "VH flanks do not reconstruct the chain"

queries = []
for _, r in ctl.iterrows():
    q = json.loads(json.dumps(proto))          # deep copy
    q["query_id"] = r.query_id
    for c in q["chains"]:
        if c["chain_id"] == "B":
            c["sequence"] = pre + r.cdrh3 + post
            assert len(c["sequence"]) == len(vh)
    queries.append(q)

os.makedirs(OUT, exist_ok=True)
json.dump({"queries": queries}, open(f"{OUT}/queries.json", "w"), indent=1)
shutil.copy(f"{PREP}/template.cif", f"{OUT}/template.cif")
ctl.to_csv(f"{OUT}/controls.csv", index=False)
print(f"wrote {len(queries)} queries to {OUT}/queries.json")
print(ctl.to_string(index=False))
