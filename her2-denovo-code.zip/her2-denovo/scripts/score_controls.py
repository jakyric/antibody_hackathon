"""Does the pipeline separate MEASURED binders from MEASURED non-binders?

Reference is PDB 1N8Z (trastuzumab-HER2). For each control refold we measure:
  iptm / ptm / plddt   straight from the folding model's scores JSON
  epitope_vs_1n8z      HER2 residues its CDRH3 contacts vs trastuzumab's real epitope
  pose_rmsd_vs_1n8z    binder displacement after superimposing on HER2
"""
import json, glob, os, re, sys, numpy as np, pandas as pd, gemmi
from scipy.stats import mannwhitneyu
from sklearn.metrics import roc_auc_score

sys.path.insert(0, "/home/hackathon/guled/denovo/scripts")
from pose_epitope import load, ca, contacts, jac, CDRH3, TARGET   # same definitions
from models import FOLD_MODELS

REF = load("/home/hackathon/rfd4/Data/12-her2/her2_fv_1n8z.cif")
REF_EP = contacts(REF)
ctl = pd.read_csv("/home/hackathon/rfd4/controls/controls.csv")
P = gemmi.Position

def pose_vs_ref(mdl):
    d, r = ca(REF, TARGET), ca(mdl, TARGET)
    ks = sorted(set(d) & set(r))
    if len(ks) < 3: return np.nan, np.nan
    sup = gemmi.superpose_positions([P(*d[k]) for k in ks], [P(*r[k]) for k in ks])
    dd, rr = ca(REF, ("B",)), ca(mdl, ("B",))
    ms = sorted(set(dd) & set(rr))
    mv = np.array([sup.transform.apply(P(*rr[k])).tolist() for k in ms])
    fx = np.array([dd[k] for k in ms])
    return sup.rmsd, float(np.sqrt(((mv - fx) ** 2).sum(1).mean()))

rows = []
for model in FOLD_MODELS:
    for sc in sorted(glob.glob(f"/home/hackathon/rfd4/controls/{model}/*/seed_*/*_scores.json")):
        qid = os.path.basename(sc).split("_seed_")[0]
        cif = sc.replace("_scores.json", "_model.cif")
        if not os.path.exists(cif): continue
        j = json.load(open(sc))
        try:
            mdl = load(cif)
            her2_fit, pose = pose_vs_ref(mdl)
            ep = jac(contacts(mdl), REF_EP)
        except Exception as e:
            print(f"  skip {qid}: {e}", file=sys.stderr); continue
        rows.append(dict(fold_model=model, query_id=qid,
                         iptm=j.get("interface_predicted_tm_score"),
                         ptm=j.get("predicted_tm_score"),
                         plddt=j.get("average_predicted_local_distance_difference_test"),
                         rank_score=j.get("model_ranking_score"),
                         her2_fit=her2_fit, pose_rmsd_vs_1n8z=pose, epitope_vs_1n8z=ep))
df = pd.DataFrame(rows).merge(ctl, on="query_id", how="left")
df.to_csv("/home/hackathon/guled/denovo/results/controls_scored.csv", index=False)
pd.set_option("display.width", 220)

for model, g in df.groupby("fold_model"):
    print(f"\n================ {model} ================")
    nat = g[g.truth == "native"]
    if len(nat):
        n = nat.iloc[0]
        print(f"POSITIVE CONTROL (trastuzumab, known structure): iptm={n.iptm:.3f} "
              f"epitope_vs_1n8z={n.epitope_vs_1n8z:.2f} pose={n.pose_rmsd_vs_1n8z:.2f} A "
              f"HER2 fit={n.her2_fit:.2f} A")
    b = g[g.truth == "binder"]; nb = g[g.truth == "nonbinder"]
    if len(b) < 3 or len(nb) < 3:
        print("not enough controls scored yet"); continue
    print(f"\nmeasured binders (n={len(b)}) vs measured non-binders (n={len(nb)}):")
    y = np.r_[np.ones(len(b)), np.zeros(len(nb))]
    for c, hi_is_good in [("iptm", True), ("ptm", True), ("plddt", True),
                          ("rank_score", True), ("epitope_vs_1n8z", True),
                          ("pose_rmsd_vs_1n8z", False)]:
        v = np.r_[b[c].values, nb[c].values]
        if np.isnan(v).any(): print(f"  {c:20s} incomplete"); continue
        s = v if hi_is_good else -v
        auc = roc_auc_score(y, s)
        u = mannwhitneyu(b[c].dropna(), nb[c].dropna())
        print(f"  {c:20s} binders={b[c].mean():7.3f}  non-binders={nb[c].mean():7.3f}  "
              f"AUC={auc:.3f}  p={u.pvalue:.3f}")
    print("\nper-design:")
    print(g.sort_values("iptm", ascending=False)[
        ["query_id", "cdrh3", "truth", "edit_distance", "iptm", "plddt",
         "epitope_vs_1n8z", "pose_rmsd_vs_1n8z"]].round(3).to_string(index=False))
