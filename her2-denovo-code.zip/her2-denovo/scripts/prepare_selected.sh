#!/usr/bin/env bash
# Make a pruned design dir foldable: recompute metrics, then refold-prepare.
# Usage: prepare_selected.sh <run-tag> [topn]   (run from ~/rfd4)
set -euo pipefail
R=$1; TOPN=${2:-20}; BASE=${3:-runs-selected}
Q=quay.io/apheris/oslo-hackathon
RFD=$Q:apheris-rfd4-proteina-v0.3.0-her2-novel-2026-11-09
run=(docker run --rm --gpus all --shm-size 16g --user "$(id -u):$(id -g)"
     -e HOME=/tmp -v /etc/passwd:/etc/passwd:ro -v "$PWD:/work" -w /work)
rm -rf "$BASE/$R/metrics" "$BASE/$R/prepared"
"${run[@]}" "$RFD" module-run metrics \
  --input "$BASE/$R/design/generation" --output "$BASE/$R/metrics"
mkdir -p "$BASE/$R/design/generation/inference_metrics"
cp "$BASE/$R/metrics/evaluation_metrics/per_example_metrics.csv" \
   "$BASE/$R/design/generation/inference_metrics/"
"${run[@]}" "$RFD" module-run refold-prepare \
  --input "$BASE/$R/design" --output "$BASE/$R/prepared" --top-n "$TOPN"
echo "PREPARE_DONE $R"
