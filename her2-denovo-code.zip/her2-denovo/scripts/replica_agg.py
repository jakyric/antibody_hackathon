"""Chai-1 per-replica confidences (50 samples/pair, real + shuffled ab-ag pairs).
Question: when forward-folding a design, does aggregating over replicas beat one sample,
and which statistic separates real binders best?"""
import zipfile, io, re, numpy as np, pandas as pd, collections, json
from sklearn.metrics import roc_auc_score

Z = "/home/hackathon/hackathon-data/sigma2-ab-ag-champloo/chai1_all_per_replica_confidence_metrics.zip"
pat = re.compile(r"system_(\d+)_(\d+)_([A-Za-z0-9]+)_([A-Za-z0-9]+)_trunk_(\d+)_scores\.model_idx_(\d+)\.npz")

z = zipfile.ZipFile(Z)
names = z.namelist()
sysd = collections.defaultdict(lambda: {"iptm": [], "agg": [], "ptm": []})
meta = {}
bad = 0
for i, n in enumerate(names):
    m = pat.match(n)
    if not m: bad += 1; continue
    nbi, agi, nbp, agp, trunk, midx = m.groups()
    key = (nbi, agi, nbp, agp)
    d = np.load(io.BytesIO(z.read(n)), allow_pickle=True)
    s = sysd[key]
    s["iptm"].append(float(d["iptm"][0])); s["agg"].append(float(d["aggregate_score"][0]))
    s["ptm"].append(float(d["ptm"][0]))
    meta[key] = 1 if nbp.lower() == agp.lower() else 0
    if i % 100000 == 0: print(f"  {i}/{len(names)}", flush=True)
print("unparsed:", bad, "systems:", len(sysd))

rows = []
for key, s in sysd.items():
    a = np.array(s["iptm"]); g = np.array(s["agg"])
    rows.append(dict(system="_".join(key), real=meta[key], n=len(a),
                     iptm_mean=a.mean(), iptm_max=a.max(), iptm_min=a.min(),
                     iptm_std=a.std(), iptm_med=np.median(a), iptm_first=a[0],
                     agg_mean=g.mean(), agg_max=g.max(), ptm_mean=np.mean(s["ptm"])))
df = pd.DataFrame(rows)
df.to_csv("/home/hackathon/guled/denovo/results/chai1_replica_stats.csv", index=False)
y = df.real.values
print(f"\nreal pairs={y.sum()}  shuffled={len(y)-y.sum()}  replicas/pair median={int(df.n.median())}\n")
out = {}
for c in ["iptm_first","iptm_mean","iptm_med","iptm_max","iptm_min","iptm_std","agg_mean","agg_max","ptm_mean"]:
    auc = roc_auc_score(y, df[c].values)
    out[c] = auc
    print(f"{c:12s} AUC={auc:.4f}")
# single-replica AUC averaged over which replica you happened to draw
rng = np.random.default_rng(0)
singles = [roc_auc_score(y, [s["iptm"][rng.integers(len(s["iptm"]))] for s in sysd.values()]) for _ in range(20)]
print(f"\nsingle random replica: AUC {np.mean(singles):.4f} +/- {np.std(singles):.4f}")
out["single_replica_mean"] = float(np.mean(singles)); out["single_replica_std"] = float(np.std(singles))
json.dump(out, open("/home/hackathon/guled/denovo/results/chai1_replica_auc.json","w"), indent=2)
