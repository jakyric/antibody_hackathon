"""Harvest designed CDRH3 loops straight from generated CIFs, so a design run can be
scored while it is still running. Then apply the challenge filter + binder model."""
import re, sys, os, glob, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from challenge_filter import evaluate

CDR = re.compile(r"YYCSR(.{8,14}?)YWGQGTLVTVSS")

def cdrh3_from_cif(path):
    txt = open(path).read()
    # one-letter sequences appear in ;...; blocks, wrapped at 80 chars
    for blk in re.findall(r";\n?([A-Z\n]+)\n;", txt):
        s = blk.replace("\n", "")
        m = CDR.search(s)
        if m: return m.group(1), s
    return None, None

def harvest(run_tags):
    rows = []
    for tag in run_tags:
        base = f"/home/hackathon/rfd4/runs/{tag}/design/generation/inference_samples"
        for d in sorted(glob.glob(base + "/*")):
            cif = glob.glob(d + "/*_generated.cif")
            if not cif: continue
            try: cdr, vh = cdrh3_from_cif(cif[0])
            except Exception as e: print(f"  skip {d}: {e}", file=sys.stderr); continue
            if not cdr: continue
            rows.append(dict(run=tag, example_id=os.path.basename(d), cdrh3=cdr,
                             structure_path=cif[0], vh=vh))
    df = pd.DataFrame(rows)
    # Attach co-generation metrics. Every run numbers its examples from zero, so
    # her2_cdrh3_0 exists in all of them: the key MUST be (run, example_id), and the
    # per-run frames must be concatenated before one single merge, not merged in a loop.
    cols = {"example_id": "example_id",
            "interchain_interactions.hbond_atom_pair_count_coi": "hbond_pairs",
            "hotspot_obedience.hotspot_obedience": "hotspot_obedience",
            "clash_metrics.frac_atoms_clashing_1p5A": "clash_frac",
            "pre_oracle_pass": "pre_oracle_pass"}
    mets = []
    for tag in run_tags:
        met = f"/home/hackathon/rfd4/runs/{tag}/design/generation/inference_metrics/per_example_metrics.csv"
        if os.path.exists(met):
            m = pd.read_csv(met)
            m = m[[c for c in cols if c in m.columns]].rename(columns=cols)
            m["run"] = tag
            mets.append(m)
    if mets:
        allm = pd.concat(mets, ignore_index=True)
        dup = allm.duplicated(["run", "example_id"]).sum()
        assert dup == 0, f"{dup} duplicate (run, example_id) rows in design metrics"
        before = len(df)
        df = df.merge(allm, on=["run", "example_id"], how="left")
        assert len(df) == before, f"metrics merge changed row count {before} -> {len(df)}"
    return df

if __name__ == "__main__":
    tags = sys.argv[1:] or ["her2-novel-s1", "her2-explore-s1"]
    df = harvest(tags)
    if df.empty: print("no designs yet"); sys.exit(0)
    sc = evaluate(df.cdrh3.tolist()).drop_duplicates("cdrh3")
    df = df.merge(sc, on="cdrh3", how="left")
    # predicted affinity (Ridge on the 180 SPR KD values, grouped-CV spearman +0.73)
    try:
        import pickle, numpy as np
        from challenge_filter import onehot
        rg = pickle.load(open("/home/hackathon/guled/denovo/results/affinity_ridge.pkl","rb"))
        ten = df.cdrh3.str.len() == 10
        df.loc[ten, "pred_pkd"] = rg.predict(onehot(df.loc[ten, "cdrh3"].tolist()))
    except (FileNotFoundError, ImportError) as e:
        print(f"note: affinity model unavailable ({e})", file=sys.stderr)
    df.to_csv("/home/hackathon/guled/denovo/results/designs_scored.csv", index=False)
    pd.set_option("display.width", 250)
    print(f"\n{len(df)} designs, {df.cdrh3.nunique()} distinct loops")
    for tag, g in df.groupby("run"):
        print(f"  {tag}: n={len(g)} distinct={g.cdrh3.nunique()} "
              f"in_screen={int(g.in_screen.sum())} pass_filter={int(g.passes_challenge_filter.sum())}")
    cols = [c for c in ["run","example_id","cdrh3","edit_from_tz","in_screen","screen_class",
            "passes_challenge_filter","p_high_binder","pred_pkd","hbond_pairs"] if c in df]
    print(df[cols].sort_values("p_high_binder" if "p_high_binder" in df else "cdrh3", ascending=False).to_string(index=False))
