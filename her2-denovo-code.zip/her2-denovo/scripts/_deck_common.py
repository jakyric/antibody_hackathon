"""Build the HER2 de novo design readout deck (python-pptx; no node on this VM)."""
from pptx import Presentation
from pptx.util import Inches as In, Pt, Emu
from pptx.dml.color import RGBColor as C
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION

DK   = C(0x02,0x2F,0x36)   # deep teal, dominant dark
TEAL = C(0x02,0x80,0x90)
MINT = C(0x02,0xC3,0x9A)
WARN = C(0xE4,0x57,0x2E)   # failure / exclusion
LT   = C(0xF7,0xF9,0xF9)
WH   = C(0xFF,0xFF,0xFF)
GREY = C(0x5A,0x6B,0x6E)
HEAD, BODY = "Cambria", "Calibri"

prs = Presentation(); prs.slide_width, prs.slide_height = In(13.333), In(7.5)
BLANK = prs.slide_layouts[6]
W = 13.333

def slide(dark=False):
    s = prs.slides.add_slide(BLANK)
    bg = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid(); bg.fill.fore_color.rgb = DK if dark else LT
    bg.line.fill.background(); bg.shadow.inherit = False
    return s

def tb(s, x, y, w, h, text, size=16, bold=False, color=GREY, font=BODY,
       align=PP_ALIGN.LEFT, space_after=6, line=None, anchor=MSO_ANCHOR.TOP):
    box = s.shapes.add_textbox(In(x), In(y), In(w), In(h))
    tf = box.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    lines = text if isinstance(text, list) else [text]
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align; p.space_after = Pt(space_after)
        if line: p.line_spacing = line
        txt, sz, bd, col = (ln if isinstance(ln, tuple) else (ln, size, bold, color))
        r = p.add_run(); r.text = txt
        r.font.size = Pt(sz); r.font.bold = bd; r.font.color.rgb = col
        r.font.name = font
    return box

def title(s, text, dark=False, sub=None):
    tb(s, 0.7, 0.45, W-1.4, 0.95, text, size=36, bold=True,
       color=WH if dark else DK, font=HEAD)
    if sub: tb(s, 0.7, 1.42, W-1.4, 0.5, sub, size=15, color=MINT if dark else TEAL)

def card(s, x, y, w, h, fill=WH, edge=None):
    sh = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, In(x), In(y), In(w), In(h))
    sh.fill.solid(); sh.fill.fore_color.rgb = fill
    sh.line.color.rgb = edge if edge else C(0xDD,0xE4,0xE5); sh.line.width = Pt(1)
    sh.adjustments[0] = 0.06; sh.shadow.inherit = False
    return sh

def stat(s, x, y, w, big, label, col=TEAL, bigsize=44):
    tb(s, x, y, w, 0.85, big, size=bigsize, bold=True, color=col, font=HEAD)
    tb(s, x, y+0.82, w, 0.75, label, size=12, color=GREY, line=1.15)

def table(s, x, y, w, rows, colw, hdr_fill=DK, fs=11, rowh=0.3):
    nr, nc = len(rows), len(rows[0])
    shp = s.shapes.add_table(nr, nc, In(x), In(y), In(w), In(rowh*nr))
    t = shp.table
    for j, cw in enumerate(colw): t.columns[j].width = Emu(int(In(w)*cw/sum(colw)))
    for i, row in enumerate(rows):
        t.rows[i].height = In(rowh)
        for j, val in enumerate(row):
            cell = t.cell(i, j); cell.text = ""
            cell.margin_left = cell.margin_right = In(0.06)
            cell.margin_top = cell.margin_bottom = In(0.02)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.fill.solid()
            cell.fill.fore_color.rgb = hdr_fill if i == 0 else (WH if i % 2 else C(0xEF,0xF4,0xF4))
            p = cell.text_frame.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT if j == 0 else PP_ALIGN.CENTER
            r = p.add_run(); r.text = str(val)
            r.font.size = Pt(fs); r.font.name = BODY; r.font.bold = (i == 0)
            r.font.color.rgb = WH if i == 0 else DK
    return t

def style_chart(ch, colors, legend=False):
    ch.has_title = False
    ch.font.size = Pt(11); ch.font.name = BODY; ch.font.color.rgb = GREY
    ch.has_legend = legend
    if legend:
        ch.legend.position = XL_LEGEND_POSITION.BOTTOM
        ch.legend.include_in_layout = False
    for si, ser in enumerate(ch.series):
        ser.format.fill.solid()
        ser.format.fill.fore_color.rgb = colors[si % len(colors)]
        ser.format.line.fill.background()
    return ch

