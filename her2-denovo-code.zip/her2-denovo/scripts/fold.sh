#!/usr/bin/env bash
# Forward-fold prepared designs with one folding model and score them.
# Usage: fold.sh <design-dir> <fold-model-key> <image-suffix>
set -euo pipefail
cd /home/hackathon/rfd4
Q=quay.io/apheris/oslo-hackathon
DD=$1; KEY=$2; IMGSUF=$3
# this project uses three folding models and no others
case "$KEY" in
  boltz2|protenix-v2|mol1-base) ;;
  *) echo "fold.sh: unsupported model '$KEY' (use boltz2, protenix-v2 or mol1-base)" >&2; exit 2 ;;
esac
RFD=$Q:apheris-rfd4-proteina-v0.3.0-her2-novel-2026-11-09
run=(docker run --rm --gpus all --shm-size 16g --user "$(id -u):$(id -g)"
     -e HOME=/tmp -v /etc/passwd:/etc/passwd:ro -v "$PWD:/work" -w /work)
PREP=$(dirname "$DD")/prepared
IMG=$Q:$IMGSUF
CMD=$(docker inspect -f '{{join .Config.Cmd " "}}' "$IMG")
TMPL=()
[ -f "$PREP/holo/template.cif" ] && TMPL=(--template-paths "$PREP/holo/template.cif")
rm -rf "$(dirname "$DD")/$KEY" "$(dirname "$DD")/scored-$KEY"
# shellcheck disable=SC2086
"${run[@]}" "$IMG" $CMD predict \
  --input "$PREP/holo/queries.json" --output "$(dirname "$DD")/$KEY" \
  "${TMPL[@]}" --write-detailed-scores true \
  --num-diffusion-samples 1 --seeds 42 --query-failures skip
"${run[@]}" "$RFD" module-run refold-score \
  --input "$DD" --output "$(dirname "$DD")/scored-$KEY" \
  --predictions "$(dirname "$DD")/$KEY" --model "$KEY"
echo "FOLD_DONE $KEY"
