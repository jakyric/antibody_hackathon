# De novo HER2 binder design: co-generation + forward folding

Design trastuzumab CDRH3 loops against HER2 domain IV with RFD4-Proteina, which
co-generates **sequence and all-atom structure together**, then check each design by
forward folding it with an independent structure predictor, and rank what survives using
the hackathon's own measured data.

Everything here runs on the hackathon VM with the local Docker images — no Foundry Hub.

**Molecule class:** these designs are a trastuzumab **Fv** — paired VH and VL on a fixed
framework, with only the 10-residue CDRH3 redesigned. **No nanobodies (VHH) are designed
here.** Nanobodies appear only in the benchmark data used for findings 1 and 2, which is
why those findings carry a cross-format caveat.

## Pipeline

```
RFD4-Proteina design        co-generate CDRH3 sequence + all-atom structure vs HER2
  -> harvest.py             pull the designed loop straight out of the generated CIF
  -> challenge_filter.py    hard gate: novelty vs all 525,063 provided sequences
  -> binder_lgbm            P(high HER2 binder), trained on the 524k FACS screen
  -> affinity_ridge         predicted pKD, trained on the 190 SPR measurements
  -> select_for_folding.py  prune to the candidates the data likes
  -> fold.sh                forward fold (template-aware) + refold-score
  -> rank on min_ipae + binder_plddt   (NOT ipTM -- see below)
```

### Run it

```bash
cd ~/rfd4                                  # folder holding Data/ and Settings/
# 1. co-generate
bash ~/guled/denovo/scripts/design.sh her2-novel-s1 her2-novel-2026-11-09 100 1
bash ~/guled/denovo/scripts/design.sh her2-explore-s1 her2-2026-11-07 100 1 --sequence-tsr-k 1

# 2. train the rankers once (CPU, ~10 min)
python scripts/train_binder.py && python scripts/affinity_model.py

# 3. score designs -- works while a design run is still going
python scripts/harvest.py her2-novel-s1 her2-explore-s1

# 4. fold only the winners
python scripts/select_for_folding.py results/designs_scored.csv runs-selected 20
bash scripts/fold.sh runs-selected/her2-novel-s1/design protenix-v2 apheris-protenix-v1.3.0-v2
bash scripts/fold.sh runs-selected/her2-novel-s1/design boltz2 apheris-boltz-v1.3.0-boltz2
```

## What the data says about ranking designs

These are the findings that shaped the pipeline. All reproducible from the scripts here.

### 0. Folding models used

This project runs **three** folding models and no others: **Boltz-2**, **Protenix-v2** and
**Mol-1 base**. The allowlist lives in `scripts/models.py`; `pose_epitope.py`,
`combine_folds.py`, `denovo_select.py` and `score_controls.py` read it, and `fold.sh`
refuses any other model name.

### 1. ipTM across antigens: weak, and measured on nanobodies (`iptm_discrim.py`)

Smorodina et al. folded 91 nanobody-antigen pairs against 91 antigens; the matrix diagonal
is the real pair, everything off-diagonal is a deliberate mismatch.

| model | AUC real vs shuffled | median real | median shuffled | TPR @ 5% FPR |
|---|---|---|---|---|
| AlphaFold3 | 0.754 | 0.500 | 0.180 | 0.49 |
| Boltz-2 | 0.645 | 0.911 | 0.884 | 0.18 |
| Chai-1 | 0.568 | 0.208 | 0.191 | 0.17 |

Boltz-2's ipTM is saturated here: a nanobody paired with an antigen it does not bind still
scores 0.884.

**Two scope limits on this result, both important.** The task is telling a *cognate* pair
from a *non-cognate* one across different antigens, which is not the same as ranking
designs against one fixed target. And every pair is a **nanobody** (single VHH domain),
while our designs are a trastuzumab **Fv** (paired VH/VL). So this is cross-antigen and
cross-format evidence. The on-format control in finding 7 reaches the opposite conclusion,
and that is the one to trust for ranking.

### 2. Extra folding seeds are wasted compute (`replica_agg.py`)

Every pair was folded 50 times. Across all 735,172 Chai-1 score files:

| statistic over 50 replicas | AUC real vs shuffled |
|---|---|
| single random replica | 0.541 +/- 0.005 |
| mean of 50 | 0.542 |
| median of 50 | 0.543 |
| max of 50 | 0.543 |
| min of 50 | 0.538 |
| std of 50 | 0.510 |

Aggregating 50 replicas buys **+0.002 AUC**. The ceiling is the metric, not sampling noise.
So: one seed per design, and spend the GPU on *different folding models* instead.

### 3. The FACS screen gives a strong ranker (`train_binder.py`)

LightGBM on one-hot CDRH3, trained on the Mehta et al. clonotype split (similar loops kept
in the same split, so the test set is unseen sequence families). Label 1 = high binder.

| model | val AUC | test AUC |
|---|---|---|
| logistic regression | 0.964 | 0.944 |
| LightGBM (800 trees) | 0.997 | **0.994** |

Test AP 0.988 at a 0.328 base rate; precision is 1.000 in the top 1%, 5% and 10% of the
held-out test set.

### 4. That number survives a leakage audit (`leakage_check.py`)

| check | result |
|---|---|
| exact sequence overlap train/test | 0 |
| cluster overlap train/test | 0 |
| AUC on test loops >= 2 mutations from *any* training sequence (n=1271) | 0.991 |
| AUC on test loops >= 3 mutations from *any* training sequence (n=182) | 0.994 |
| AUC from edit-distance-to-trastuzumab alone | 0.752 |

The model is not just reading off distance from trastuzumab. **Caveat:** most held-out
sequences still sit 1-2 mutations from something in training, so the n=182 slice is the
closest analogue to a genuinely novel loop. Extrapolation to loops far from the whole
screen is less certain than 0.994 suggests.

### 5. It transfers to an independent assay (`validate_on_spr.py`)

The classifier never saw SPR data. Scored against the 190 SPR KD measurements:

| set | result |
|---|---|
| spearman(P(high), pKD), all SPR with KD (n=187) | +0.346 |
| spearman(P(high), pKD), **loops not in the FACS screen** (n=160) | **+0.455** |
| AUC quantified_binding vs no_reportable_kd (187 vs 441) | 0.716 |
| same, excluding loops seen in FACS (160 vs 432) | 0.746 |

The four tightest measured binders (KD 0.023-0.079 nM) all score 0.92-1.00.
Note `no_reportable_kd` is not a true negative, so 0.746 is a floor, not a clean AUC.

### 6. Affinity is predictable, not just binding (`affinity_model.py`)

Ridge on one-hot, 180 distinct 10-mer CDRH3 with a measured KD, grouped 5-fold CV
(folds split by trastuzumab-mutation pattern so near-identical loops stay together):

| model | spearman | MAE (log units) |
|---|---|---|
| Ridge | **+0.730** | 0.57 |
| random forest | +0.666 | 0.57 |
| predict the mean | - | 0.83 |
| edit distance from trastuzumab alone | -0.421 | - |

### 7. Ground-truth controls: ipTM ranks, geometry rejects (`build_controls.py`, `score_controls.py`)

The decisive test. Trastuzumab's own CDRH3 plus 8 FACS-measured binders and 8 measured
non-binders, matched on edit distance from trastuzumab, folded through the same Boltz-2 +
template path as every design.

**Positive control passes.** `WGGDGFYAMD` folded from sequence lands on the real 1N8Z
epitope at overlap **1.00**, pose **2.17 A**, HER2 fit 0.49 A. The template withholds the
CDRH3, so Boltz-2 places the loop itself. The pose agreement reported throughout is
genuine structural agreement, not template-copying.

| metric | binders (n=8) | non-binders (n=8) | AUC | p | verdict |
|---|---|---|---|---|---|
| **ipTM** | 0.950 | 0.923 | **0.867** | **0.015** | rank on this |
| pTM | 0.961 | 0.944 | 0.820 | 0.035 | usable |
| ranking score | 0.961 | 0.951 | 0.656 | 0.328 | no |
| pLDDT | 96.4 | 95.8 | 0.594 | 0.574 | no |
| pose RMSD | 2.32 A | 2.33 A | 0.484 | 0.959 | no |
| epitope vs 1N8Z | 0.814 | 0.903 | 0.289 | 0.156 | below chance |

**Epitope overlap is below chance against measured binding.** With the framework fixed by
the template, every real sequence lands near the trastuzumab epitope at 1.8-3.0 A. It
separates *designs* (0.00-1.00) because some genuinely drift, so it is a gate for catching
a drifted design -- not a ranking metric. An earlier version of this README and the deck
used it to rank candidates; that was wrong.

**So: rank on ipTM, use geometry to reject.** n=8 per class, so treat 0.867 as a direction
rather than a precise AUC, and the gap to pTM's 0.820 as not meaningful.

### 8. Within one model, ipTM leads min_ipae (`combine_folds.py`)

Across all 89 Boltz-2 refolds: spearman(ipTM, epitope overlap) = **+0.584** (p=2e-09)
versus min_ipae's -0.525 (p=1e-07). An earlier analysis reported ipTM as flat
(0.950-0.968) and non-discriminating, but that was measured on a shortlist already gated
at pose <= 10 A and epitope >= 0.2 -- gates that remove the variance ipTM tracks. On the
full set ipTM runs 0.623-0.968.

### Not used: `topmodel_structure_accuracy.zip`

Described as "a structure accuracy score for each top-ranked prediction", but the values
run from 1 to 95,587 with no column documentation in the archive, and are not a bounded
accuracy measure. Not used; the script that probed it has been removed.

## The challenge filter (`challenge_filter.py`)

A design passes if:

1. its CDRH3 differs at **>= 2 of 10 positions from every sequence in the provided data**
   (524,346 FACS variants + the SPR designs = 525,063 unique loops), and
2. it is **at most 70% identical to trastuzumab's `WGGDGFYAMD`** (>= 3 of 10 positions changed).

Rule 1 is checked exactly, not by sampling: a design fails if the loop itself or any of its
190 single-mutant neighbours is in the provided set, which is equivalent to Hamming >= 2
from everything. Verified against known inputs — trastuzumab itself and sampled FACS loops
are all correctly rejected.

## Verification run

Pipeline verified end to end on the HER2 example (4 designs, Boltz-2 with HER2 template):

| design | binder_ptm | min_ipae | binder_plddt | backbone_rmsd | iptm |
|---|---|---|---|---|---|
| her2_cdrh3_2 | 0.991 | 0.331 | 95.6 | 1.04 | 0.946 |
| her2_cdrh3_3 | 0.993 | 0.310 | 98.5 | 0.74 | 0.965 |

`pass` is blank for this example by design: HER2 is fixed only relative to the framework,
not in absolute coordinates, so target-aligned RMSDs are undefined and the scorer says so
in `pass_note`. This is documented upstream — rank on `min_ipae` / `binder_plddt` instead.

## Tests

`pytest -q tests/` — 19 tests, each naming the failure it guards against:

- the folding-model allowlist, and that every other model name is refused
- the novelty rule: a design fails if it or any of its 190 single mutants is in the
  provided data, checked at every one of the 10 positions
- the <= 70% identity rule, including the exactly-3-edits boundary
- non-canonical residues (a literal `X`) rejected
- CDRH3 extraction from a VH sequence
- **the run-id collision**: design metrics must key on `(run, example_id)`, since every
  run numbers its examples from zero; the test also asserts the broken form fans 2 rows
  into 4
- **the pivot collision**: fold scores must key on `(run, cdrh3)`, or two runs producing
  the same loop are silently averaged
- **the model gate**: a folding model needs pose and epitope checks, not just HER2 fit,
  or a model that rebuilds the target and then docks the binder 21 A away passes as usable

## Files

| path | what |
|---|---|
| `scripts/design.sh` | co-generate N designs with a chosen weight build |
| `scripts/fold.sh` | forward fold prepared designs with one model + refold-score |
| `scripts/harvest.py` | pull CDRH3 from generated CIFs, filter and score (works mid-run) |
| `scripts/challenge_filter.py` | novelty gate + binder scoring, importable |
| `scripts/train_binder.py` | P(high binder) model on the FACS screen |
| `scripts/affinity_model.py` | pKD model on the SPR measurements |
| `scripts/leakage_check.py` | leakage audit of the binder model |
| `scripts/validate_on_spr.py` | independent FACS-model check against SPR |
| `scripts/models.py` | the three folding models this project uses; nothing else is read |
| `scripts/build_controls.py` | build the measured-binder / measured-non-binder control set |
| `scripts/score_controls.py` | score the controls against PDB 1N8Z ground truth |
| `scripts/pose_epitope.py` | pose RMSD and epitope overlap for every refold |
| `scripts/denovo_select.py` | the gated selection rule and one-per-cluster dedup |
| `scripts/iptm_discrim.py` | ipTM real-vs-shuffled discrimination (nanobody benchmark) |
| `scripts/replica_agg.py` | does aggregating 50 fold replicas help? |
| `scripts/select_for_folding.py` | prune a design run to the candidates worth folding |
| `scripts/prepare_selected.sh` | make a pruned design run foldable (metrics + refold-prepare) |
| `scripts/build_deck_models.py` | build the readout deck (.pptx) |
| `deck/` | the readout decks and the browser deck's source |
| `results/binder_lgbm.pkl` | trained binder classifier |
| `results/affinity_ridge.pkl` | trained affinity model (use this one, not the RF) |
| `results/designs_scored.csv` | harvested designs with filter + both scores |
| `results/controls_scored.csv` | the ground-truth control results |
| `results/pose_epitope.csv` | pose and epitope per refold, per model |
| `results/final_selection.csv` | the gated, cluster-deduplicated shortlist |
| `results/top20.csv` | the top 20 with ipTM and min_ipae |
| `results/chai1_replica_stats.csv` | per-system replica statistics behind finding 2 |

## Data

Not committed (250 MB+). Re-fetch:

```bash
aws s3 sync s3://apheris-oslo-hackathon/data/ ~/hackathon-data/
```

Then unpack into `denovo/data/`: `tz_her2_facs_3classes_524346.csv`,
`trastuzumab_her2_spr_all_768.csv`, `iptm/` (from `iptm_confidence_scores.zip`) and
`splits/` (the `0.7_0.15_0.15` clonotype split inside `data.zip`).

## Credit

- FACS and SPR data: Chinery et al., doi:10.1101/2024.03.26.586756
- Clonotype splits: Mehta et al., doi:10.5281/zenodo.10831512 (CC BY 4.0)
- ipTM / replica confidence data: Smorodina et al., doi:10.5281/zenodo.18390239 (CC BY 4.0);
  AlphaFold3 outputs are non-commercial research use only
